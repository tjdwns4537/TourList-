﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TourApp.View;

namespace TourApp.ViewModel
{
    public class StartWindow_temp
    {
        StartWindow startwindow;  
        public StartWindow_temp()
        {
            startwindow = new StartWindow();
        }
    }
}
