﻿using System.Windows;
using System;
using TourAPI.ViewModel;
using WpfApp1.Classes;
using System.Xml;
using TourAPI.Classes;
using System.Net.Http;

namespace WpfApp1
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            //this.DataContext = this;            
        }
    }
}
