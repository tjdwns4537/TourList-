﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TourApp.Classes
{
    public class TourLIstDATA
    {
        public string addrData { get; set; }
        public string titleData { get; set; }
        public string firstimageData { get; set; }
        public string secondimageData { get; set; }
    }
}
